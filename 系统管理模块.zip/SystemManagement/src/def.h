#ifndef DEF
#define DEF
#include <unistd.h>
#include <errno.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
/*
 * 
 */

#define MAX_PATH 100
#define CURRENTDB "currentDb.txt"
#define ALLDB "allDb.txt"
#define TABLELIST "tablelist.txt"

#endif
